#include <iostream>

int main() {
    cout << "Hello, C++!\n";
}
