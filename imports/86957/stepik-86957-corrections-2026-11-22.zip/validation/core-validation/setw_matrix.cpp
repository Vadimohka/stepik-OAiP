#include <iostream>
#include <iomanip>

const unsigned int DIM1 = 3;
const unsigned int DIM2 = 5;

int **array_generator(unsigned int dim1, unsigned int dim2) {
    int **ptrary = new int * [dim1];
    for (int i = 0; i < dim1; i++) {
        ptrary[i] = new int [dim2];
    }
    return ptrary;
}

void array_destroyer(int **ary, unsigned int dim1) {
    for (int i = 0; i < dim1; i++) {
        delete [] ary[i];
    }
    delete [] ary;
}

int main() {

    int **matrix;

    // создание массива
    matrix = array_generator(DIM1, DIM2);

    // использование
    for (int i = 0; i < DIM1; i++) {
        for (int j = 0; j < DIM2; j++) {
            matrix[i][j] = (i + 1) * 10 + (j + 1);
            std::cout << std::setw(4) << matrix[i][j];
        }
    }

    // уничтожение
    array_destroyer(matrix, DIM1);
    return 0;
}